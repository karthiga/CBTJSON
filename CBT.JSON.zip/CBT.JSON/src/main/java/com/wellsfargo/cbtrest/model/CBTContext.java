package com.wellsfargo.cbtrest.model;

import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;


@ApiModel( value = "Context", description = "CBT WS Context" )
public class CBTContext {
	@ApiModelProperty( value = "WS Context Message Id", required = false ) private String messageId;
	@ApiModelProperty( value = "WS Context Originator", required = false ) private String originator;
		
	public CBTContext() {
	}
		
	public CBTContext( final String originator, final String messageId) {
		this.messageId = messageId;
		this.originator = originator;
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(final String messageId) {
		this.messageId = messageId;
	}

	public String getOriginator() {
		return originator;
	}

	public void setOriginator(final String originator) {
		this.originator = originator;
	}
}