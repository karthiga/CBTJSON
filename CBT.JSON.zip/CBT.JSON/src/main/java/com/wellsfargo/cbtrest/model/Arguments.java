package com.wellsfargo.cbtrest.model;


import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;


@ApiModel( value = "Arguments", description = "CBT WS Arguments" )
public class Arguments {
	@ApiModelProperty( value = "WS Context Message Id", required = false ) private String[] argument;
		
	public Arguments() {
	}
		
	public Arguments( final String[] argument) {
		this.argument = argument;
	}

	public String[] getArgument() {
		return argument;
	}

	public void setArgument(String[] argument) {
		this.argument = argument;
	}

	
}