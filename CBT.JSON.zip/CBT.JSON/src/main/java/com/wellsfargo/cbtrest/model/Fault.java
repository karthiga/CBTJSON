package com.wellsfargo.cbtrest.model;

import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;


@ApiModel( value = "Fault", description = "CBT WS Fault" )
public class Fault {
	@ApiModelProperty( value = "WS Fault Type", required = true ) private String exception;
	@ApiModelProperty( value = "WS Fault Details", required = true ) private String details;
		
	public Fault() {
	}
		
	public Fault( final String exception, final String details) {
		this.exception = exception;
		this.details = details;
	}

	public String getException() {
		return exception;
	}

	public void setException(final String exception) {
		this.exception = exception;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(final String details) {
		this.details = details;
	}

		
}