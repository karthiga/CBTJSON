package com.wellsfargo.cbtrest.model;

import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;

@ApiModel( value = "CBTRequest", description = "CBT Request" )
public class CBTResponse {
	@ApiModelProperty( value = "WS Return value if Success", required = false ) private String value;
	@ApiModelProperty( value = "WS Context", required = false ) private CBTContext context;
	@ApiModelProperty( value = "WS Fault if failue", required = false ) private Fault fault;
		
	public CBTResponse() {
	}
		
	public CBTResponse( final String value) {
		this.value = value;
	}
	
	public CBTResponse( final String value, final CBTContext context) {
		this.value = value;
		this.context = context;
	}
	
	public CBTResponse( final Fault fault, final CBTContext context) {
		this.fault = fault;
		this.context = context;
	}
	
	public CBTResponse( final Fault fault) {
		this.fault = fault;
	}

	public String getValue() {
		return value;
	}

	public void setValue(final String value) {
		this.value = value;
	}

	public CBTContext getContext() {
		return context;
	}

	public void setContext(final CBTContext context) {
		this.context = context;
	}

	public Fault getFault() {
		return fault;
	}

	public void setFault(final Fault fault) {
		this.fault = fault;
	}

}
