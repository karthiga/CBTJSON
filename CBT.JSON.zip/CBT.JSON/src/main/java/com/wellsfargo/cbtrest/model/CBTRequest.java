package com.wellsfargo.cbtrest.model;

import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;

@ApiModel( value = "CBTRequest", description = "CBT Request" )
public class CBTRequest {
	@ApiModelProperty( value = "WS Package Name", required = true ) private String component;
	@ApiModelProperty( value = "WS Method Name", required = true ) private String function;
	@ApiModelProperty( value = "WS Context", required = false ) private CBTContext context;
	@ApiModelProperty( value = "WS Context", required = false ) private Arguments arguments;
		
	public CBTRequest() {	
	}
		
	public CBTRequest( final String component, final String function) {
		this.component = component;
		this.function = function;
	}
	
	public CBTRequest( final CBTContext context, final String component, final String function) {
		this.component = component;
		this.context = context;
		this.function = function;
	}

	public String getComponent() {
		return component;
	}

	public void setComponent(final String component) {
		this.component = component;
	}

	public String getFunction() {
		return function;
	}

	public void setFunction(final String function) {
		this.function = function;
	}

	public CBTContext getContext() {
		return context;
	}

	public void setContext(final CBTContext context) {
		this.context = context;
	}

	public Arguments getArguments() {
		return arguments;
	}

	public void setArguments(final Arguments arguments) {
		this.arguments = arguments;
	}

}
