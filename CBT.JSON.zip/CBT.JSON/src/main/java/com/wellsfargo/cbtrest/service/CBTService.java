package com.wellsfargo.cbtrest.service;

import com.wellsfargo.cbtrest.model.CBTRequest;
import com.wellsfargo.cbtrest.model.CBTResponse;
import com.wellsfargo.cbtrest.model.Fault;

public class CBTService {

	public CBTResponse processCBTRequest(CBTRequest request) {
		String newline = System.getProperty("line.separator");
		CBTResponse response = new CBTResponse();

		if (null != request.getContext()) {
			response.setContext(request.getContext());
		}

		if (request.getComponent().contains("wellsfargo")) {
			response.setValue("Processed Successfully");
		} else {
			Fault fault = new Fault();
			fault.setException("java.lang.NullPointerException");
			fault.setDetails("Exception in thread \"main\" java.lang.NullPointerException"
					+ newline
					+ "at com.example.myproject.Book.getTitle(Book.java:16)"
					+ newline
					+ "at com.example.myproject.Author.getBookTitles(Author.java:25)"
					+ newline
					+ "at com.example.myproject.Bootstrap.main(Bootstrap.java:14)");
			response.setFault(fault);
		}

		return response;
	}

}
